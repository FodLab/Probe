//
//  Probe.h
//  Probe
//
//  Created by TaurusXAds on 2020/3/9.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for Probe.
FOUNDATION_EXPORT double ProbeVersionNumber;

//! Project version string for Probe.
FOUNDATION_EXPORT const unsigned char ProbeVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Probe/PublicHeader.h>

#import <Probe/ProbeSDK.h>
