//
//  MsgCarrierManager.h
//  msgCarrier
//
//  Created by zena.tang on 2020/6/5.
//  Copyright © 2020 taurusX. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MsgCarrierManager : NSObject

@property (nonatomic) BOOL             testMode;
@property (nonatomic, readonly) NSString *appId;

+ (instancetype)getManager;

+ (void) initWithAppId: (NSString *)appId;

+ (int)getSdkVersion;

+ (BOOL)msgWarningOn;


+ (void)showNotice:(void(^ __nullable)(void))dismissBlock;


@end

NS_ASSUME_NONNULL_END
